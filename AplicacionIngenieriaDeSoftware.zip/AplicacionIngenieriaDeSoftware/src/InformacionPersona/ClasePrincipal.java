package InformacionPersona;

public class ClasePrincipal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		
		PanelUsuarioContrasena frame = new PanelUsuarioContrasena ();
		//frame.setVisible(true);
	}

}
